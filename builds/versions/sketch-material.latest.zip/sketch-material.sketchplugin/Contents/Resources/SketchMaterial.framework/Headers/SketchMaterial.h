//
//  SketchMaterial.h
//  SketchMaterial
//
//  Created by Siddhartha Gudipati on 8/12/17.
//  Copyright © 2017 gsid. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SketchMaterial.
FOUNDATION_EXPORT double SketchMaterialVersionNumber;

//! Project version string for SketchMaterial.
FOUNDATION_EXPORT const unsigned char SketchMaterialVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SketchMaterial/PublicHeader.h>

#import "ServiceManager.h"
